// Full canonical schema code from previous answer
