// Full recommender.service code from previous answer
