// Full catalog.service code from previous answer
