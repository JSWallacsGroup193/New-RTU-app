// Full disambiguator.service code from previous answer
