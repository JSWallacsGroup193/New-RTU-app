// Full parse.controller code from previous answer
