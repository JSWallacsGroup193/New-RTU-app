// Full sku.controller code from previous answer
