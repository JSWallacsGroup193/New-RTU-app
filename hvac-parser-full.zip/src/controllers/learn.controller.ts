// Full learn.controller code from previous answer
