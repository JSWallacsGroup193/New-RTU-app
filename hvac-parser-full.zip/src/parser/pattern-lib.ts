// Full pattern-lib code from previous answer
