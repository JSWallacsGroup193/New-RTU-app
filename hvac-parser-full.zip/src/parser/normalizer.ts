// Full normalizer code from previous answer
