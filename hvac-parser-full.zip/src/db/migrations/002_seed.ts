// Full migration 002 code from previous answer
