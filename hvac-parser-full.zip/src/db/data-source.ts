// Full data-source code from previous answer
