# HVAC Parser + Recommender (MVP)

## Setup
`pnpm install && pnpm build && pnpm start`
