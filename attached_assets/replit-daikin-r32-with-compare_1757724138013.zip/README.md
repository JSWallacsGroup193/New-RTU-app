# Replit Starter — Daikin R‑32 Packaged Units (Schema + Builder)

This project bundles:
- **Full master schema** with 8.5T (`102`) + nearest-match fallback logic (tons, gas BTU, electric kW).
- **TypeScript builder/parser** supporting numeric fallback (`buildModelWithFallback`) and code-first (`buildModel`).
- **Tests** to smoke-check 8.5T and accessories mapping.

## Quick Start on Replit
1. Create a new **Node.js** Repl.
2. Upload the contents of this folder *as-is* (keep the structure).
3. Open the Repl shell and run:
   ```bash
   npm install
   npm run dev
   ```
   You should see a built model and nearest-match details printed from `src/index.ts`.

## Run Tests
```bash
npm test
```

## Files
- `src/daikin_r32_master_schema_with_fallback_FULL.json` — the full schema.
- `src/daikin_r32_builder.ts` — builder/parser with numeric fallback + size ladder.
- `src/index.ts` — sample usage.
- `src/daikin_r32_builder.test.ts` — lightweight tests (ts-node).
- `package.json`, `tsconfig.json` — build/run config for Replit.


---

## Compare Against Your Code

### 1) Schema diff
Upload your schema JSON to the Replit workspace (e.g., `src/my_schema.json`) and run:
```bash
npx ts-node src/schema_diff.ts src/my_schema.json
```
You’ll get a list of `[added|removed|changed]` keys and values, so you can spot gaps (e.g., missing `102`, fallback logic, p15–p24 options).

### 2) Behavior harness
Upload your builder module (TS or compiled JS). Then run:
```bash
npx ts-node src/behavior_harness.ts ./path/to/your_builder.js
```
It will run a few representative cases (9 tons → 8.5, 160k BTU → 150k, boundary clips, etc.) and print **our output** vs **your output** for quick eyeballing.

> Tip: If your builder only supports code-first (no numeric fallback), the harness will try to adapt inputs (map 8.5 → `102`, etc.) so you still get comparable strings.
