#!/bin/bash
echo 'swap script'
