declare module "../../../decode.js" { export function decode(raw:string): any }
