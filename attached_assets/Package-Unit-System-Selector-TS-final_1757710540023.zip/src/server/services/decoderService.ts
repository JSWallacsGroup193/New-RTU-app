export function decodeModel(raw:string){return {raw};}
