export function registerMetricsRoutes(){}
