export function registerDecodeRoutes(){}
